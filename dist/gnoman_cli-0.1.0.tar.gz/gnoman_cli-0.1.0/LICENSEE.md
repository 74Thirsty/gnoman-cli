
Permission is hereby granted to the Licensee ("Your Name") to use,
modify, market, and distribute GNOMAN ("the Software") as a proprietary product.

Redistribution, modification, sublicensing, or resale by any third party is
strictly prohibited without prior written consent of the copyright holder.

No warranties are provided. The Software is offered "as is" without warranty of
any kind, either expressed or implied, including but not limited to the implied
warranties of merchantability, fitness for a particular purpose, and
noninfringement. In no event shall the copyright holder be liable for any claim,
damages, or other liability, whether in action of contract, tort, or otherwise,
arising from, out of, or in connection with the Software.

Commercial Use
--------------
Your Name retains full rights to use GNOMAN for commercial purposes,
including licensing, SaaS deployment, and resale.

Trademark
---------
The name "GNOMAN" and associated logos or branding are proprietary to
Christopher Hirschauer. Use of the name or branding in derivative works,
advertisements, or promotional materials is prohibited without explicit permission.

For permissions, contact:  
Christopher Hirschauer  
Sioux City Iowa, USA
